package play;

public class Speak {
	private static int space = 0;
	public void Speak(){
		// TODO 自動生成されたメソッド・スタブ
		Speak_text Epi = new Speak_text();
	
		
		Epi.Epi0();
	}

public void S(String moji, int speed) {

	String[] strArray = new String[moji.length()];
	for(int i=0;i<moji.length();i++) {
		strArray[i]=String.valueOf(moji.charAt(i));
	}
	for(int i=0;i<strArray.length;i++) {
		System.out.print(strArray[i]);
		try {
			Thread.sleep(speed);
			 // speed間だけ処理を止める
		} catch (InterruptedException e) {
		}
	}
	waitSpace();
	System.out.println("");
}
public void waitSpace() {
	while(true) {
		if(space==1) {
			break;
		}
		System.out.print("");
	}
	space = 0;
}
public static void setSpace(int space) {
	Speak.space = space;
}
}