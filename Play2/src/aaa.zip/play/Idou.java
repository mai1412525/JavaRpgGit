package play;

public class Idou {
	public void idousyori(){
		
	}
}
