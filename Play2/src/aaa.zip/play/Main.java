package play;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;

class TestWindow extends JFrame implements KeyListener {

	TestWindow(String title, int width, int height) {
		super(title);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(width,height);
		setLocationRelativeTo(null);
		setLayout(null);
		setResizable(false);

		//キー入力の有効化
		addKeyListener(this);
		sub.syougai();
		sub.tekiidou();
	}
	int Mkirikae = 0;
	sub sub = new sub();
	Event Event = new Event();


@Override
public void keyTyped(KeyEvent e) {
	// TODO 自動生成されたメソッド・スタブ

}

@Override
public void keyPressed(KeyEvent e) {
	int i = 0;
	
	// TODO 自動生成されたメソッド・スタブ
	//0がマップ、1が選択肢、2が会話文
	Mkirikae = Event.get_Event();
	System.out.println("今のMain切り替え"+Mkirikae);
	switch (e.getKeyCode()) {
	case KeyEvent.VK_UP:
		if(Mkirikae == 0) {
			sub.idou(5);
			sub.dispz();
		}
		else if(Mkirikae == 1) {
			if(i > 0) {
				i--;
			}
			Event.set_select_number(i);
			
			//senta.sentaku(i, takusi);
		}
		break;

	case KeyEvent.VK_DOWN:
		if(Mkirikae == 0) {
			sub.idou(2);
		}
		else if(Mkirikae == 1) {
				i++;
			Event.set_select_number(i);
		}
		break;

	case KeyEvent.VK_RIGHT:
		if(Mkirikae == 0) {
			sub.idou(3);
		}
		break;

	case KeyEvent.VK_LEFT:
		if(Mkirikae == 0) {
			sub.idou(1);
		}
		break;

	case KeyEvent.VK_SPACE:
		if(Mkirikae == 1) {
			System.out.println("決定押された");
			
		}
			/*if(takusi[i] == "はい") {
				syoji.setmotiflg(0);

			sub.tansaku(6,3);
			kirikae = 0;
			sub.setkirikae(kirikae);
			syoji.setmoti(0);
			sub.dispz();
		}*/
		else if(Mkirikae==2) {
			//System.out.println("Speakに送って");
			Speak.setSpace(1);
			
		}
		break;
	}

}

void kaigyou() {
	for(int i=0;i<10;i++) {
		System.out.println("");
	}
}

@Override
public void keyReleased(KeyEvent e) {
	// TODO 自動生成されたメソッド・スタブ

}

}

