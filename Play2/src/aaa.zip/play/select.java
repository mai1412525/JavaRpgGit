package play;
import java.awt.event.KeyEvent;


public class select {	
    String[] moji_join;
    int select_number;//Mainで使う用
    public static int select_final;//Eventに送る用
select(){
	
}
public void select(String moji) {//設定
	String[] moji_Split = moji.split(",");
	String[] moji_Join = new String[moji_Split.length*2];
    for (int i = 0; i < moji_Split.length; i++) {
        moji_Join[i * 2] = "▶";
        moji_Join[i * 2 + 1] = moji_Split[i];
    }
	this.moji_join = moji_Join;
	for(int i=0;i<moji_join.length;i++) {
		System.out.println(moji_join[i]);
	}
	dispSelect(0);//選択肢表示
}

public void dispSelect(int sentaku) {//表示
	sentaku = select_number;
	if(moji_join.length>1 && sentaku < moji_join.length/2 ) {
		for(int i=0;i<moji_join.length/2;i++) {
			if(sentaku==i) {
				System.out.print(moji_join[i*2]);
			}
			else {
				System.out.print(" ");
			}
			System.out.println(moji_join[i*2+1]);
	}
}

	
}
}
