package play;



public class Event {
	static int number;//選択肢の番号を一時保存
	String[] flag2 = new String[10];//フラグ管理
	select select = new select();
	Speak_text Epi = new Speak_text();
	Speak s = new Speak();
	static int Ekirikae=0;
	int No=99;
	
	public void prorogu() {
	System.out.println("あなたの名前を教えてください");
	Ekirikae = 1;
	select.select("いいえ,はい");

	}
	
	
	
	

	public void set_select_number (int num) {
		num = this.number;
		select.dispSelect(number);
	}
	public int get_Event() {
		return Ekirikae;
	}
}

